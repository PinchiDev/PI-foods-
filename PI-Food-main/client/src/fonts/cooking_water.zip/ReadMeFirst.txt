This font is free for personal use. 
If you want to use it for commercial project 
you can visit and buy from my store here

https://creativemarket.com/jozgandoz

or directy contact me at email
joztype@gmail.com

Thanks